Write-Output 'Custom PowerShell profile in effect!'
